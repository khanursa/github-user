package com.reston.githubuser.view.`interface`

interface ProgressInterface {
    fun onSucces()

    fun onFailled()
}