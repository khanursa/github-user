package com.reston.githubuser.consumergithubuser.view.`interface`

interface ProgressInterface {
    fun onSucces()

    fun onFailled()
}